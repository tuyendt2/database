#include <fstream>
#include<stdio.h>
#include <string>
#include "msg.h"
#include <stdlib.h>
#include "slist.h"
#include "msg_sgn.h"
typedef struct data_list{
	slist * L_message;
	slist * L_signal;
} data_list;
void show_sig(void *data);
void output(void *data);
void out_signal(void *data);
void saveFile_signal(ofstream &out,void *data);
void saveFile(ofstream &out,void *data);
 data_list loadDatabase(ifstream &in);
bool id_compare(void * data1, void * data2);
void release_msg(void *data);
void release_signal(void *data);
bool compare_signal(void * sig1,void * sig2);