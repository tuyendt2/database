#ifndef MSG_H
#define MSG_H
#include <iostream>
#include<string.h>
#include "slist.h"
#include "mylib.h"
#include "cstdint"
#include "sgn.h"
using namespace std;
class msg{
public:
	msg();
	msg(ifstream &in,char *str);
	msg(index_arr result);
	void setId(uint64_t id);
	void setDLC(int DLC);
	void setName(string name);
	void setSyn(string s);
	void setSgnList(slist *list);
	void setType(string type);
	uint64_t getId();
	int getDLC();
	string getName();
	string getSyn();
	void toString();
	slist* getSgnList();
	string getType();
	void update_signal(sgn * signal);
private:
	uint64_t ID;
	int DLC;
	string name;
	string syntax;
	slist *sgn_list;
	string type;
};

#endif