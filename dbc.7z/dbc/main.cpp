#include <iostream>
#include "function.h"
#include "mylib.h"
using namespace std;

int main(){
	ofstream out;
	ifstream in;
	char *name;
	char path[]="";
    in.open("C:/Users/HCD-Fresher295/Desktop/a.dbc");
	// load database 
	data_list d =loadDatabase(in);
	slist *msg_list=d.L_message;
	slist *signal_list=d.L_signal;
	out_put_list_data(msg_list,output);
	cout<<"signal list signal list  signal list signal list signal list : "<<endl;
	out_put_list_data(signal_list,out_signal);
	in.close();


	// edit message 
	cout<<"Add message"<<endl;
	msg *message = new msg();
	msg_list = slist_append(msg_list,(void*)message);

	// add signal
	cout<<"Do you want to add signal?"<<endl;
	msg_sgn *signal = new msg_sgn();
	signal->toString();
	sgn *sig =static_cast<sgn*>(signal);
	cout<<"sau khi ep kieu"<<endl;
	sig->toString();
	// add above signal to sig_list 
	slist_append(((msg*)msg_list->data)->getSgnList(),(void*)signal);


	//test remove message by id
	int id;
	cout<<"enter the ID of message you need to remove "<<endl;
	cin>>id;
	msg_list=slist_remove_by_index(msg_list,slist_find_index(msg_list,(void*)id,id_compare),release_msg);


	// edit messages
	int a;
	cout<<"enter id of message u want to edit: "<<endl;
	cin>>a;
	msg *editMsg =(msg*)(slist_find(msg_list,(void*)a,id_compare))->data;
	editMsg->toString();
	editMsg->setName("editedMsg");

	
	// new messaged_signal 
	int id_msg ,index;
	cout<<"enter ID messaged "<<endl;
	cin>>id_msg;
	cout<<"enter index signal in list_signal"<<endl;
	cin>>index;
	sgn * addSignal;
	//sgn *addSignal =(sgn*)slist_get_item_by_index(signal_list,index);
	slist *it=signal_list;
	int i=0;
	while(it){
		if(i==index) {
			addSignal = (sgn*) it->data;
		}
		it=it->next;
		i++;
	}
	//addSignal->toString();
	msg_sgn * messaged_signal_add =static_cast<msg_sgn *>(addSignal);
	messaged_signal_add->setSbit(10);
	msg *addSignalMessage =(msg*)(slist_find(msg_list,(void*)id_msg,id_compare))->data;
	addSignalMessage->setSgnList( slist_append( addSignalMessage->getSgnList(),messaged_signal_add));


	// edit messaged_signal 
	int editID,indexS;
	cout<<"enter id message u want to edit " <<endl;
	cin>>editID;
	cout<<"enter index signal in list_signal of that message"<<endl;
	cin>>indexS;
	msg * editSignalMessage =(msg*)(slist_find(msg_list,(void*)editID,id_compare))->data;
	slist *sgn_list_of_message  = editSignalMessage->getSgnList(); 
	slist * editWalk=sgn_list_of_message;
	int j=0;
	while(editWalk){
		if(indexS==j) break;
		j++;
		editWalk = editWalk->next;
	}
	((msg_sgn*)editWalk->data)->setName("edit_signal_1");
	cout<<"to string "<<endl;
	((msg_sgn*)editWalk->data)->toString();


	//remove messaged_signal by index 
	int Rid,Rindex;
	cout<<"enter id message u want to remove " <<endl;
	cin>>Rid;
	cout<<"enter index signal in list_signal of that message"<<endl;
	cin>>Rindex;
	msg * RSignalMessage =(msg*)(slist_find(msg_list,(void*)Rid,id_compare))->data;
	slist *Rsgn_list_of_message  = RSignalMessage->getSgnList();
	Rsgn_list_of_message= slist_remove_by_index(Rsgn_list_of_message,Rindex,release_signal);

	//edit signal 
	// note : when edit a signal , all messaged signal will be change immediately
	int Eindex;
	cout<<"enter index signal u want to edit"<<endl;
	cin>>Eindex;
	slist * Ewalk=signal_list;
	slist * tempWalk;
	int k=0;
	while(Ewalk){
		if(k==Eindex){
			tempWalk=Ewalk;
			((sgn*)Ewalk->data)->setName("Edit signal hehe !");	
		}
		k++;
		Ewalk = Ewalk->next ;
	}
	slist *EmsgWalk= msg_list;

	while(EmsgWalk){
		slist * EsgnList = ((msg*)EmsgWalk->data)->getSgnList();
		slist * sgnWalk = EsgnList;
		while(sgnWalk){
			if(compare_signal(sgnWalk,tempWalk)){
				sgnWalk = Ewalk;

			}
			sgnWalk= sgnWalk->next;	
		}
		EmsgWalk = EmsgWalk->next;
	}
	// save
	
	cout<<"Save file name : "<<endl;
	name= (char*) malloc(sizeof(char));
	cin.ignore();
	cin.getline(name,100);
	char *fullPath = (char*)malloc(sizeof(char)*(strlen(path)+strlen(name)+1));
	strcpy(fullPath,path);
	
	strcat(fullPath,name);
	out.open(fullPath);
	slistSaveFile(msg_list, out,saveFile);
	out.close();
	system("pause");
	return 0;
}
