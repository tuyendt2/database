#ifndef MYLIB_H
#define MYLIB_H

#include <iostream>
#include <string.h>

using namespace std;

typedef struct index_arr{
	char ** arr;
	int index;
} index_arr ;
bool compare_arr(char *a,char *b);
index_arr split(char str[]);

#endif // !MYLIB_H