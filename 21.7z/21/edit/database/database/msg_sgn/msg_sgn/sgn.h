#ifndef SGN_H
#define SGN_H

#include "mylib.h"
#include <iostream>
#include<string.h>
using namespace std;
class sgn{
public:
	sgn();
	sgn(string mux,string name,int length,char by_order,char val_type,
	float factor,int offset,int min,int max,string unit,string syntax,string comment);
	void setMux(string mux);
	void setName(string name);
	void setLength(int length);
	void setByteOrder(char byteOrder);
	void setValType(char valType);
	void setFactor(float factor);
	void setOffset(int offset);
	void setMin(int min);
	void setMax(int max);
	void setUnit(string unit);
	void setSyntax(string syntax);
	void setComment(string comment);
	string getMux();
	string getName();
	int getLength();
	char getByOrder();
	char getValType();
	float getFactor();
	int getOffset();
	int getMin();
	int getMax();
	string getUnit();
	string getSyntax();
	string getComment();
	void toString();
protected:
	string mux;
	string name;
	int length;
	char by_order;
	char val_type;
	float factor;
	int offset;
	int min;
	int max;
	string unit;
	string syntax;
	static int sgn_index;
	string comment;
};

#endif // !SGN_H
