#include "sgn.h"
using namespace std;

// default constructor method 
sgn::sgn(){
	sgn_index++;
	this->setByteOrder('1');
	this->setValType('-');
	this->setFactor(1);
	this->setOffset(0);
	this->setLength(8);
	this->setMax(0);
	this->setMin(0);
	this->setName(" New_Signal"+(char)sgn_index);
	this->setMux("");
	this->setSyntax("Vector__XXX");
	this->setUnit("");
	//this->setSbit(0);
}
//set methods
void sgn::setMux(string mux){
	this->mux=mux;}
void sgn::setName(string name){
	this->name=name;}
void sgn::setLength(int length){
	this->length=length;}
void sgn::setByteOrder(char byteOrder){
	this->by_order=byteOrder;}
void sgn::setValType(char valType){
	this->val_type=valType;}
void sgn::setFactor(float factor){
	this->factor=factor;}
void sgn::setOffset(int offset){
	this->offset=offset;}
void sgn::setMin(int min){
	this->min=min;}
void sgn::setMax(int max){
	this->max=max;}
void sgn::setUnit(string unit){
	this->unit=unit;}
void sgn::setSyntax(string syntax){
	this->syntax=syntax;}
void sgn::setComment(string comment){
	this->comment=comment;
}
// get methods
char sgn::getByOrder(){
	return this->by_order;
}
string sgn::getName(){
	return this->name;
}
string sgn::getMux(){
	return this->mux;
}
string sgn::getUnit(){
	return this->unit;
}
char sgn::getValType(){
	return this->val_type;
}
float sgn::getFactor(){
	return this->factor;
}
int sgn::getLength(){
	return this->length;
}
int sgn::getMax(){
	return this->max;
}
int sgn::getMin(){
	return this->min;
}
int sgn::getOffset(){
	return this->offset;
}
string sgn::getSyntax(){
	return this->syntax;
}
string sgn::getComment(){
	return this->comment;
}

void sgn::toString(){
	cout<<"SG : \n";
	cout<<"SGN name : "<<this->name.c_str()<<endl;
	//cout<<"Start bit : "<<this->s_bit<<endl;
	cout<<"Length : "<<this->length<<endl;
	cout<<"By order : "<<this->by_order<<endl;
	cout<<"Valtype : "<<this->val_type<<endl;
	cout<<"Factor : "<<this->factor<<endl;
	cout<<"Offset : "<<this->offset<<endl;
	cout<<"Min : "<<this->min<<endl;
	cout<<"Max : "<<this->max<<endl;
	cout<<"Unit : "<<this->unit.c_str()<<endl;
	cout<<"Syntax : "<<this->syntax.c_str()<<endl;
}