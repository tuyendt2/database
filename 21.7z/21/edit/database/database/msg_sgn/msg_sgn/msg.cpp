#include <iostream>
#include "msg.h"
#include<string.h>
#include<fstream>
#include "mylib.h"
#include "slist.h"
using namespace std;
// constructor default 
msg::msg(){
	char name[100];
	char syn[100];
	this->setSgnList(NULL);
	cout<<"nhap ID"<<endl;
	cin>>this->ID;
	if(this->ID>>7!=0){
	this->setType("Extended");
	}else{
		this->setType("Standard");
	}
	cout<<"nhap DLC"<<endl;
	cin>>this->DLC;
	cout<<"nhap Name"<<endl;
	cin.ignore();
	cin>>name;
    this->setName(name);
	cout<<"nhap Syntax "<<endl;
	cin.ignore();
	cin>>syn;
	this->setSyn(syn);
	cin.ignore();
}


// constructor with ifstream input
msg::msg(ifstream &in, char *str){

		if(compare_arr(str,"BO_")){
			in.getline(str,100,' ');
			in.getline(str,100,' ');
			this->setId(atol(str));
			in.getline(str,100,':');
			this->setName(str); 
			in.getline(str,100,' ');
			in.getline(str,100,' ');
			this->setDLC(atoi(str));
			in.getline(str,100);
			this->setSyn(str);
			//this->toString();
		}		
}
// constructor with char array input
msg::msg(index_arr result){
	//index_arr result =split(str);
	//"BO_ 2147483650 New_Message_3: 8 Vector__XXX"
	if(compare_arr( result.arr[0],"BO_")){
	//cout<<"message"<<endl;
	this->setName(result.arr[2]);
	this->setDLC(atoi(result.arr[3]));
	this->setId(atol(result.arr[1]));
	//this->setId((uint64_t)(result.arr[1]));
	//we'll do the following work later
	//this->setSgnList(result.arr[1]);
	this->setSyn(result.arr[4]);
	//sig.toString();
	if(this->ID>>7!=0){
	this->setType("Extended");
	}else{
		this->setType("Standard");
	}
	}
	
}
void msg::setId(uint64_t id){
	this->ID=id;
}
void msg::setDLC(int DLC){
	this->DLC=DLC;
}
void msg::setName(string name){
	this->name=name;
}
void msg::setSyn(string s){
	this->syntax=s;
}
void msg::setSgnList(slist *list){
	this->sgn_list=list;
}
void msg::setType(string type){
	this->type=type;
}
uint64_t msg::getId(){
	return this->ID;
}
int msg::getDLC(){
	return this->DLC;
}
string msg::getName(){
	return this->name;
}
string msg::getSyn(){
	return this->syntax;
}
slist* msg::getSgnList(){
	return this->sgn_list;}
string msg::getType(){
	return this->type;}
void msg::toString(){
	//printf("%s",name);
	cout<<"ID : "<<this->getId()<<endl;
	cout<<"Name : "<<this->getName().c_str()<<endl;
	cout<<"DLC : "<<this->getDLC()<<endl;
	cout<<"Syntax : "<<this->getSyn().c_str()<<endl;
	cout<<"Type : "<<this->getType().c_str()<<endl;
}
