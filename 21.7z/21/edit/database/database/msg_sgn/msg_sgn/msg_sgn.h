#ifndef MSG_SGN
#define MSG_SGN

#include "mylib.h"
#include <iostream>
#include<string.h>
#include "sgn.h"
using namespace std;
class msg_sgn : public sgn{
public:
	
	msg_sgn();
	msg_sgn(sgn *new_signal);
	msg_sgn(ifstream &in, char *str);
	msg_sgn(index_arr result);
	void setSbit(int s_bit);
	int getSbit();
	void toString();
private:
	int s_bit;
};
#endif // !MSG_SGN