#include <iostream>
#include<string.h>
#include<fstream>
#include"mylib.h"
using namespace std;
int main(){
	ofstream out ;
	out.open("C:/Users/DINHTUYEN/Desktop/can database/b.txt");
	ifstream in;
	in.open("C:/Users/DINHTUYEN/Desktop/can database/a.dbc");
	char str[100];
	char line[1000];
	while(!in.eof()){
		in>>str;
		cout<<str<<endl;
	}

	system("pause");
	return 0;
}